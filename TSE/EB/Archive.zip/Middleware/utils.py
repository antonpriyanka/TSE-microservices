import jwt

user_source = jwt.decode(source, 'verify-user-234234', algorithm='HS256')

def create_authorisation_token(email):
    return jwt.encode({'source':email}, 'verify-user-234234', algorithm='HS256').decode('utf-8')