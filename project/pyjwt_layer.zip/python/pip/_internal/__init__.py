#!/usr/bin/env python
import pip._internal.utils.inject_securetransport  # noqa
